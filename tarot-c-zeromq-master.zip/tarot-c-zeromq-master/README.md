
## Tarot description program in C.


*Gives description based on cards drawn, deck shuffles dynamically.*

Server-client based program with support for multiple clients. Server checks if clients are connected and clients connect with a random generated ID. Server checks if ID doesn't exist and assigns an ID itself.
Source:
 - Deck from http://www.m31.de/colman-smith/index.html

